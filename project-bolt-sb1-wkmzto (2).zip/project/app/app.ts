import { Application } from '@nativescript/core';

Application.run({ moduleName: 'views/home/home-page' });
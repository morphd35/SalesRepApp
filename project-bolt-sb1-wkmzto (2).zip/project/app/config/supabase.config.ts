export const SUPABASE_CONFIG = {
    URL: 'https://plqaijyafkqxyprvcaar.supabase.co',
    ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBscWFpanlhZmtxeHlwcnZjYWFyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU3NTEzMTEsImV4cCI6MjA1MTMyNzMxMX0.l_QtRxcicCacI357WOxAgZCzDjz38miVHaA1Zp0A7Xc'
};
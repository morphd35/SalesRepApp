/*
  # Add RLS policies for accounts table

  1. Security
    - Enable RLS on accounts table
    - Add policies for authenticated users to:
      - Read all accounts
      - Insert new accounts
      - Update their own accounts
*/

-- Enable RLS
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read all accounts
CREATE POLICY "Allow authenticated users to read accounts"
ON accounts FOR SELECT
TO authenticated
USING (true);

-- Allow authenticated users to insert accounts
CREATE POLICY "Allow authenticated users to insert accounts"
ON accounts FOR INSERT
TO authenticated
WITH CHECK (true);

-- Allow authenticated users to update accounts
CREATE POLICY "Allow authenticated users to update accounts"
ON accounts FOR UPDATE
TO authenticated
USING (true);
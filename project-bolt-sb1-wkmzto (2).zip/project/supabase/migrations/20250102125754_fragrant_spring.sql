-- Drop existing profiles table and related objects
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user CASCADE;
DROP TABLE IF EXISTS profiles;

-- Update accounts table to use email instead of user_id
ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS owner_email TEXT REFERENCES auth.users(email);

-- Update RLS policies for accounts
DROP POLICY IF EXISTS "Users can read own accounts" ON accounts;
DROP POLICY IF EXISTS "Users can insert own accounts" ON accounts;
DROP POLICY IF EXISTS "Users can update own accounts" ON accounts;

CREATE POLICY "Users can read own accounts"
    ON accounts FOR SELECT
    TO authenticated
    USING (owner_email = auth.jwt() ->> 'email');

CREATE POLICY "Users can insert own accounts"
    ON accounts FOR INSERT
    TO authenticated
    WITH CHECK (owner_email = auth.jwt() ->> 'email');

CREATE POLICY "Users can update own accounts"
    ON accounts FOR UPDATE
    TO authenticated
    USING (owner_email = auth.jwt() ->> 'email');
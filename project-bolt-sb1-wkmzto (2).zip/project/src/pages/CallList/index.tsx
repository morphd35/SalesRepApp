import { useEffect, useState } from 'react';
import { format, differenceInDays } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { Account } from '../../types/account';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../features/auth/hooks/useAuth';
import QuickActionButtons from '../../components/QuickActionButtons';

export default function CallList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchAccounts();
    }
  }, [user]);

  async function fetchAccounts() {
    try {
      setLoading(true);
      const tenDaysAgo = new Date();
      tenDaysAgo.setDate(tenDaysAgo.getDate() - 10);

      const { data, error } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', user?.id)
        .lt('last_contact_date', tenDaysAgo.toISOString())
        .order('last_contact_date', { ascending: true });

      if (error) throw error;
      setAccounts(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center py-4">Loading call list...</div>;
  }

  if (error) {
    return <div className="text-red-600 py-4">{error}</div>;
  }

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-2xl font-semibold text-gray-900">Call List</h1>
          <p className="mt-2 text-sm text-gray-700">
            Accounts that haven't been contacted in the last 10 days
          </p>
        </div>
      </div>

      {/* Mobile View */}
      <div className="mt-8 lg:hidden space-y-4">
        {accounts.map((account) => (
          <div key={account.id} className="bg-white shadow rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-medium text-gray-900">{account.business_name}</div>
                <div className="text-sm text-gray-600 mt-1">{account.contact_name}</div>
              </div>
              <div className="text-sm font-medium text-red-600">
                {differenceInDays(new Date(), new Date(account.last_contact_date))} days
              </div>
            </div>
            <div className="mt-4 flex justify-between items-center">
              <div className="text-sm text-gray-500">
                Last Contact: {format(new Date(account.last_contact_date), 'MMM d, yyyy')}
              </div>
              <QuickActionButtons
                phone={account.phone}
                email={account.email}
                onSchedule={() => navigate('/appointments', { state: { selectedAccount: account } })}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Desktop View */}
      <div className="hidden lg:block mt-8">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                  Business Name
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Contact Name
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Last Contact
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Days Since Contact
                </th>
                <th className="relative py-3.5 pl-3 pr-4">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {accounts.map((account) => (
                <tr key={account.id}>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">
                    {account.business_name}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {account.contact_name}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {format(new Date(account.last_contact_date), 'MMM d, yyyy')}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {differenceInDays(new Date(), new Date(account.last_contact_date))} days
                  </td>
                  <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                    <QuickActionButtons
                      phone={account.phone}
                      email={account.email}
                      onSchedule={() => navigate('/appointments', { state: { selectedAccount: account } })}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}